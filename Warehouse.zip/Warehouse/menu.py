import os

def menu():
    print("-"*30)
    print(" Warehouse Control ")
    print("-"*30)
    print("1 - Register Items")
    print("2 - Catalog Items")
    print("3 - Out of Stock")
    print("4 - Update of Stock")
    print("5 - Total Stock")
    print("6 - Delete Item")
    print("7 - Registry Sale")
    print("8 - Log Events")

    print("[x] Exit")

def header(title):
    print("-"*75)
    print(title)
    print("-"*75)


def clear():
    return os.system("cls")

