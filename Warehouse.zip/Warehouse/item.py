class Item:
    id = 0
    title = ""
    category = ""
    price = 0.0
    stock = 0