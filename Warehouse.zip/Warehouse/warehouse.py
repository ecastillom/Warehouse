"""
    Warehouse Management System
    Funcionality:
        - Repeted Menu
        - Register Items
        - Display Catalog
        - Display Out of Stock

        - Saving / Get data from file

        -Update the stock of an item
            +Show the list items
            +ask the user to choose and ID
            +ask the user for the new stock value
            +dfin the item with selected ID
            +update the stock
            +save the change
        
"""

from menu import menu, clear, header
from item import Item
import datetime
import pickle

catalog = []
log = []
last_id = 0
data_file = "warehouse.data"
log_file = "log.data"

def save_catalog():
    global data_file
    writer = open(data_file, "wb") #Create File (overwrite), open it to writa Binary
    pickle.dump(catalog, writer)
    writer.close()
    print("*** Data Saved!!")

def read_catalog():
    try:
        global data_file
        global last_id

        reader = open(data_file,"rb")
        temp_list = pickle.load(reader)

        for item in temp_list:
            catalog.append(item)

        last = catalog[-1]
        
        last_id = last.id

        how_many = len(catalog)
        print("** Loaded " + str(how_many) + " items")
    
    except:
        print("** No Data ") 

def read_catalogUpdateStock(id_aux):
    try:
        found = False
        for item in catalog:
            if(item.id == id_aux):
                found = True
                
                item.stock = input("New Stock: ")
                
                add_log_event("StockUpdate","Item Stock Update: " + str(id_aux) )
                print("**Stock Updated!!")
                    # add_log_event("Sale","Sale item for: " + str(item.id))

        
        if(found == False):
            print("Item not exists")
        
    except:
        print("** No Data ")

def read_catalogSaleStock(id_aux, stoc_aux):
    try:
        found = False
        for item in catalog:
            if(item.id == id_aux):
                found = True
                new_stock = item.stock - stoc_aux

                if (new_stock < 0):
                    print("\n")
                    print("**Error!!!")
                    print("You want to Sale: " + str(stoc_aux))
                    print("You have in Stock: " + str(item.stock) )
                    print("\n")
                else:
                    item.stock = stoc_aux
                    add_log_event("SaleItem","Item Sale: " + str(id_aux) )
                    print("**Sale Registry!!")
                    # add_log_event("Sale","Sale item for: " + str(item.id))

        
        if(found == False):
            print("Item not exists")
        
    except:
        print("** No Data ")
        

def read_catalogDeleteStock(id_aux):
    found = False
    for item in catalog:
        if(item.id == id_aux):
            found = True
            opc = input("Are you sure? (y/n): ")
    
            if (opc == "y"):
                catalog.remove(item)
                
                add_log_event("DeleteItem","Item Delete: " + str(id_aux) )
                print("Item Delete!!")
                print("\n")
            
            elif(opc == "n"):
                print("Item NO DELETE!!!")
                print("\n")
            
            else:
                print("Wrong option!!!")
                print("\n")
                opc = input("Are you sure? (y/n): ")
        
        if(found == False):
            print("Item not exists")

def save_log():
    global log_file
    writer = open(log_file,'wb')
    pickle.dump(log,writer)
    writer.close()
    # print("** Log Saved!!! ")


def read_log():
    try:
        global log_file
        reader = open(log_file, "rb")
        temp_list = pickle.load(reader)

        for entry in temp_list:
            log.append(entry)
        
        how_many = len(log)
        print("** Loaded " + str(how_many) + " log entries")
    except:
        print("** Error Loading Log Entry")

#functions
def register_item():
    global last_id
    clear()
    header("1. Register New Item")
    title = input("New item Title: ")
    category = input("New item Category: ")
    price = float(input("New item Price: "))
    stock = int(input("New item Stock: "))

    new_item = Item()
    last_id += 1 
    new_item.id = last_id
    new_item.title = title
    new_item.category = category
    new_item.price = price
    new_item.stock = stock
    catalog.append(new_item)

    add_log_event("NewItem","Item Added: " + str(last_id) )
    print("\n")
    print("** Item Created!!! ")
    # print(new_item)
    print("\n")
    input("Press Enter to Continue...")

def display_catalog():
    clear()    
    header("2. Catalog Items")

    size = len(catalog)

    print("There are: " + str(size) + " items")

    print("\n")
    
    print("|" + "ID".rjust(2)
    + "  | " + "Title".ljust(25)
    + "  | " + "Category".ljust(15)
    + "  |  " + "Price".rjust(10)
    + " | " + "Stock".rjust(5)
    + " | ")

    print("-"*75)

    for item in catalog:
        print("|" + str(item.id).rjust(2)
        + "  | " + item.title.ljust(25)
        + "  | " + item.title.ljust(15)
        + "  | $" + str(item.price).rjust(10)
        + " | " + str(item.stock).rjust(5)
        + " | ")
        print("-"*75)

    print("\n")
    input("Press Enter to Continue...")

def display_outofstock():
    clear()    
    header("3. Out of Stock")

    size = 0

    for item in catalog :
        if (item.stock <= 0):
            size = size + 1

    print("There are: " + str(size) + " items")

    print("\n")
    
    print("|" + "ID".rjust(2)
    + "  | " + "Title".ljust(25)
    + "  | " + "Category".ljust(15)
    + "  |  " + "Price".rjust(10)
    + " | " + "Stock".rjust(5)
    + " | ")

    print("-"*75)

    for item in catalog :
        if (item.stock <= 0):
            print("|" + str(item.id).rjust(2)
            + "  | " + item.title.ljust(25)
            + "  | " + item.title.ljust(15)
            + "  | $" + str(item.price).rjust(10)
            + " | " + str(item.stock).rjust(5)
            + " | ")
            print("-"*75)

    print("\n")
    input("Press Enter to Continue...")

def update_outofstock():
    clear()    

    header("4. Update Out of Stock")

    size = len(catalog)

    print("There are: " + str(size) + " items")

    print("\n")
    
    print("|" + "ID".rjust(2)
    + "  | " + "Title".ljust(25)
    + "  | " + "Category".ljust(15)
    + "  |  " + "Price".rjust(10)
    + " | " + "Stock".rjust(5)
    + " | ")

    print("-"*75)

    for item in catalog:
        print("|" + str(item.id).rjust(2)
        + "  | " + item.title.ljust(25)
        + "  | " + item.title.ljust(15)
        + "  | $" + str(item.price).rjust(10)
        + " | " + str(item.stock).rjust(5)
        + " | ")
        print("-"*75)

    print("\n")
    
    id_aux = int(input("ID for Update: ")) 
    read_catalogUpdateStock(id_aux)
    input("Press Enter to Continue...")

def registry_sale():
    clear()    

    header("7. Registry Sale")

    size = len(catalog)

    print("There are: " + str(size) + " items")

    print("\n")
    
    print("|" + "ID".rjust(2)
    + "  | " + "Title".ljust(25)
    + "  | " + "Category".ljust(15)
    + "  |  " + "Price".rjust(10)
    + " | " + "Stock".rjust(5)
    + " | ")

    print("-"*75)

    for item in catalog:
        print("|" + str(item.id).rjust(2)
        + "  | " + item.title.ljust(25)
        + "  | " + item.title.ljust(15)
        + "  | $" + str(item.price).rjust(10)
        + " | " + str(item.stock).rjust(5)
        + " | ")
        print("-"*75)

    print("\n")
    
    id_aux = int(input("ID for Sale: ")) 
    items_sale = int(input("Total Items Sale: ")) 

    read_catalogSaleStock(id_aux,items_sale)
    input("Press Enter to Continue...")

def sum_stock():
    clear()    

    header("5. Total Stock")

    size = len(catalog)
    total = 0
    for item in catalog:
        total = total + (item.stock * item.price)
    
    print("Total Items: " + str(size))
    print("Total for all Stock: $" + str(total))
    print("\n")
    input("Press Enter to Continue...")


def delete_item():
    clear()    

    header("6. Delete Item")

    size = len(catalog)

    print("There are: " + str(size) + " items")

    print("\n")
    
    print("|" + "ID".rjust(2)
    + "  | " + "Title".ljust(25)
    + "  | " + "Category".ljust(15)
    + "  |  " + "Price".rjust(10)
    + " | " + "Stock".rjust(5)
    + " | ")

    print("-"*75)

    for item in catalog:
        print("|" + str(item.id).rjust(2)
        + "  | " + item.title.ljust(25)
        + "  | " + item.title.ljust(15)
        + "  | $" + str(item.price).rjust(10)
        + " | " + str(item.stock).rjust(5)
        + " | ")
        print("-"*75)

    print("\n")
    
    id_aux = int(input("ID for Delete: ")) 
    read_catalogDeleteStock(id_aux)
    input("Press Enter to Continue...")
          

def get_current_time():
    now = datetime.datetime.now()
    return now.strftime("%b/%d/%Y %T")

def add_log_event(event_type, event_description):
    entry = get_current_time() + " | " + event_type.ljust(10) + " | " + event_description
    log.append(entry)
    save_log()

def print_log():
    clear()    

    header("6. Delete Item")
    for entry in log:
        print(entry)
    
    print("\n")
    input("Press Enter to Continue...")

#-------Start Menu-------------------------
read_catalog()
input("Press Enter to Continue...")

opc = ""
while (opc != "x"):
    clear()
    menu()
    print("\n")
    opc = input("Type option: ")

    if(opc == "1"):
        register_item()
        save_catalog()
    elif (opc == "2"):
        display_catalog()
    elif (opc == "3"):
        display_outofstock()
    elif (opc == "4"):
        update_outofstock() 
        save_catalog()
    elif (opc == "5"):
        sum_stock()
    elif (opc == "6"):
        delete_item()
        save_catalog()
    elif (opc == "7"):
        registry_sale()
        save_catalog()
    elif (opc == "8"):
        print_log()

input("Press Enter to Continue...")
